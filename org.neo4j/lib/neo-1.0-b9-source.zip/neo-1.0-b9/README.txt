To get started and for more information about Neo4j, go to http://neo4j.org.

Quick start for non-Maven users:

o add neo-1.0-b9.jar and jta-1_1.jar to your classpath/project
o javadoc for the Neo4j API can be found at http://api.neo4j.org/current
  (in eclipse right click neo.jar Properties->Javadoc location)
o see javadoc for org.neo4j.api.core.EmbeddedNeo to get started

Also see the Getting Started Guides at http://wiki.neo4j.org.

